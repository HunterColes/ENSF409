import java.io.IOException;

public class Referee {

	/**
	 * Player playing as 'X'
	 */
	private Player xPlayer;
	/**
	 * Player playing as 'O'
	 */
	private Player oPlayer;
	/**
	 * The game board
	 */
	private Board board;
	/**
	 * gets Board
	 * @return board
	 */
	public Board getBoard() {
		return board;
	}
	/**
	 * sets Board
	 * @param board
	 */
	public void setBoard(Board board) {
		this.board = board;
	}
	/**
	 * gets oPlayer
	 * @return oPlayer
	 */
	public Player getoPlayer() {
		return oPlayer;
	}
	/**
	 * sets oPlayer
	 * @param oPlayer
	 */
	public void setoPlayer(Player oPlayer) {
		this.oPlayer = oPlayer;
	}
	/**
	 * sets xPlayer
	 * @return
	 */
	public Player getxPlayer() {
		return xPlayer;
	}
	/**
	 * sets xPlayer
	 * @param xPlayer
	 */
	public void setxPlayer(Player xPlayer) {
		this.xPlayer = xPlayer;
	}
	/**
	 * sets opponents and then calls play
	 * @throws IOException
	 */
	public void runTheGame() throws IOException
	{
		xPlayer.setOpponent(oPlayer);
		oPlayer.setOpponent(xPlayer);
		
		xPlayer.play();
	}
	
	
}
