

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Player {

	/**
	 * Player name
	 */
	private String name;
	/**
	 * The game board
	 */
	private Board board;
	/**
	 * reference to opposing player
	 */
	private Player opponent;
	/**
	 * Either an 'X' or an 'O' depending on player
	 */
	private char mark;
	/**
	 * default constructor for Player that sets the name and mark of a player
	 * @param player name
	 * @param player mark
	 */
	public Player (String name, char mark)
	{
		setName(name);
		setMark(mark);
	}
	/**
	 * gets Opponent
	 * @return opponent
	 */
	public Player getOpponent() {
		return opponent;
	}
	/**
	 * sets Opponent
	 * @param opponent
	 */
	public void setOpponent(Player opponent) {
		this.opponent = opponent;
	}
	/**
	 * gets Mark
	 * @return mark
	 */
	public char getMark() {
		return mark;
	}
	/**
	 * sets Mark
	 * @param mark
	 */
	public void setMark(char mark) {
		this.mark = mark;
	}
	/**
	 * gets Board
	 * @return board
	 */
	public Board getBoard() {
		return board;
	}
	/**
	 * sets Board
	 * @param board
	 */
	public void setBoard(Board board) {
		this.board = board;
	}
	/**
	 * gets Name
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * sets Name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * This function makes a move, displays the board, checks if
	 * a player has won and then calls the next player
	 * @throws IOException
	 */
	public void play() throws IOException
	{
	makeMove();
	board.display();
	
		if(board.xWins() || board.oWins())
		{
			System.out.println(name + " wins, better luck next time "+ opponent.getName());
			System.exit(1);
		}
	
		if(board.isFull())
		{
		System.out.println("Tie game, try again");
		System.exit(1);
		}
	
		opponent.play();
	
	}
	/**
	 * prompts the user to makes a move and calls add mark
	 * @throws IOException
	 */
	public void makeMove() throws IOException
	{
		int row, col;
		String loc;
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println(name+", what row should your next "+ mark +" be placed in?");
		loc = in.readLine();
		row = Integer.parseInt(loc);	
		System.out.println(name+", what column should your next "+ mark +" be placed in?");
		loc = in.readLine();
		col = Integer.parseInt(loc);
		
		board.addMark(row, col, mark);
	}
}
